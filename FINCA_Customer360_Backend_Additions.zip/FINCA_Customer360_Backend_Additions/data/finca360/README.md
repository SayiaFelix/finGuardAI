FINCA Customer 360 Rich Synthetic Dataset — KES v3

- All monetary values use currency=KES. The UI may display this as Ksh.
- Numeric amounts remain numeric in JSON.
- Customer/location/phone data is synthetic and Kenya-oriented.
- device_id is an opaque technical ID.
- device_name/device_model are realistic analyst-facing labels.
- Transaction IDs use the same long-form style as the existing fraud demo.
- IPs use documentation-only ranges and repeat per customer.
- Shared-device relationships are included.
